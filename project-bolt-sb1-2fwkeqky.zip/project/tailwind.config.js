/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
      },
      colors: {
        cream: '#fbf8f3',
        lake: {
          50: '#f0f7f8',
          100: '#dcedf0',
          200: '#b9dbe2',
          300: '#8cc3cf',
          400: '#5ea6b7',
          500: '#3f8a9e',
          600: '#2f6f81',
          700: '#295a69',
          800: '#264b57',
          900: '#233f4a',
        },
        walnut: {
          50: '#faf6f2',
          100: '#f2e9df',
          200: '#e3d0bc',
          300: '#cfb095',
          400: '#b98f6c',
          500: '#a47450',
          600: '#8a5d3f',
          700: '#6f4a33',
          800: '#5a3e2c',
          900: '#4a3427',
        },
        saffron: {
          300: '#f7c96a',
          400: '#f0b43f',
          500: '#dc9a1f',
          600: '#b87d12',
        },
        success: { 50: '#ecf7f0', 100: '#d3ecdc', 600: '#2f6b4a', 700: '#285a3e' },
        warning: { 50: '#fffbeb', 100: '#fef3c7', 600: '#b45309', 700: '#92400e' },
        error: { 50: '#fef2f2', 100: '#fee2e2', 600: '#b91c1c', 700: '#991b1b' },
      },
    },
  },
  plugins: [],
};
