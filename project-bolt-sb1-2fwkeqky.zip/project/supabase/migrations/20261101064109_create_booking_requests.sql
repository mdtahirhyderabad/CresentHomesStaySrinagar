/*
# Create booking requests table

1. New Tables
- `booking_requests`
  - `id` (uuid, primary key)
  - `guest_name` (text, required, 2 to 100 characters)
  - `guest_email` (text, required, basic email shape)
  - `guest_phone` (text, required, 7 to 20 characters)
  - `check_in` (date, required)
  - `check_out` (date, required, must be after check_in)
  - `guests` (integer, 1 to 10)
  - `room_type` (text, required)
  - `meal_plan` (text, required)
  - `message` (text, optional, up to 500 characters)
  - `created_at` (timestamp, defaults to now)

2. Security
- Enable RLS on `booking_requests`.
- Grant INSERT only to `anon` and `authenticated`. Guests can send a request but cannot read, change, or delete any request, including their own.
- A single INSERT policy checks that every field is present and within limits, so malformed requests are rejected by the database itself.

3. Important notes
- The site has no sign-in, so the owner reviews requests through the database dashboard for now.
- Re-running this migration is safe: the table and policy creation are idempotent.
*/

CREATE TABLE IF NOT EXISTS booking_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  guest_name text NOT NULL CHECK (char_length(guest_name) BETWEEN 2 AND 100),
  guest_email text NOT NULL CHECK (char_length(guest_email) BETWEEN 5 AND 254 AND guest_email LIKE '%_@_%.__%'),
  guest_phone text NOT NULL CHECK (char_length(guest_phone) BETWEEN 7 AND 20),
  check_in date NOT NULL,
  check_out date NOT NULL,
  guests integer NOT NULL CHECK (guests BETWEEN 1 AND 10),
  room_type text NOT NULL CHECK (char_length(room_type) BETWEEN 1 AND 100),
  meal_plan text NOT NULL CHECK (char_length(meal_plan) BETWEEN 1 AND 100),
  message text CHECK (message IS NULL OR char_length(message) <= 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT booking_dates_valid CHECK (check_out > check_in)
);

ALTER TABLE booking_requests ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON booking_requests TO anon, authenticated;

DROP POLICY IF EXISTS "anon_insert_booking_requests" ON booking_requests;
CREATE POLICY "anon_insert_booking_requests" ON booking_requests
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);
