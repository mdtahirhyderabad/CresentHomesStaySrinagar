import { useEffect, useState } from 'react';
import { Menu, Moon, X } from 'lucide-react';
import { homestay } from '@/data/homestay';

const navLinks = [
  { href: '#rooms', label: 'Rooms' },
  { href: '#stay', label: 'Stay' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#book', label: 'Book' },
  { href: '#contact', label: 'Contact' },
];

function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const solid = scrolled || menuOpen;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid ? 'bg-cream/95 text-walnut-900 shadow-sm backdrop-blur' : 'bg-transparent text-white'
      }`}
    >
      <div className="mx-auto flex h-20 max-w-6xl items-center justify-between px-6">
        <a href="#top" className="flex items-center gap-2 font-serif text-xl font-semibold">
          <Moon size={22} className="text-saffron-400" aria-hidden="true" />
          {homestay.name}
        </a>

        <nav className="hidden items-center gap-8 text-sm font-medium md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 transition-opacity hover:opacity-70 after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:origin-left after:scale-x-0 after:bg-current after:transition-transform hover:after:scale-x-100"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#book"
            className="hidden rounded-full bg-saffron-400 px-5 py-2.5 text-sm font-semibold text-walnut-900 transition-colors hover:bg-saffron-300 md:inline-flex"
          >
            Book now
          </a>
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-expanded={menuOpen}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            className="rounded-full p-2 transition-colors hover:bg-walnut-900/10 md:hidden"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="flex flex-col gap-1 border-t border-walnut-100 px-6 py-4 md:hidden">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="rounded-lg px-3 py-3 text-base font-medium hover:bg-walnut-100"
            >
              {link.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}

export default SiteHeader;
