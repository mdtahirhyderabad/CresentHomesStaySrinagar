import { Moon } from 'lucide-react';
import { homestay } from '@/data/homestay';

function SiteFooter() {
  return (
    <footer className="bg-walnut-900 py-10 text-walnut-100">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-sm md:flex-row">
        <div className="flex items-center gap-2 font-serif text-lg text-white">
          <Moon size={20} className="text-saffron-300" aria-hidden="true" />
          {homestay.name}
        </div>
        <p className="text-walnut-200">{homestay.location}</p>
        <p className="text-walnut-200">© {new Date().getFullYear()} {homestay.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default SiteFooter;
