import SectionHeading from '@/components/ui/SectionHeading';
import { galleryImages } from '@/data/homestay';

function GallerySection() {
  return (
    <section id="gallery" className="scroll-mt-20 bg-cream py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Gallery"
          title="Views from the water and the hills"
          description="A glimpse of the lake, the boats, the mountains, and the food waiting for you."
        />

        <div className="mt-16 grid auto-rows-[220px] grid-cols-2 gap-4 md:grid-cols-3 md:auto-rows-[260px]">
          {galleryImages.map((image, index) => (
            <figure
              key={image.src}
              className={`group relative overflow-hidden rounded-2xl bg-walnut-100 ${
                index === 0 ? 'col-span-2 row-span-2' : ''
              }`}
            >
              <img
                src={image.src}
                alt={image.alt}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-lake-900/85 to-transparent px-5 pb-4 pt-12 text-sm font-medium text-white">
                {image.caption}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

export default GallerySection;
