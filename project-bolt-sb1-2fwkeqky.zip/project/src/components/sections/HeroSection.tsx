import { Car, Mountain, Wifi } from 'lucide-react';
import { homestay } from '@/data/homestay';

const HERO_IMAGE =
  'https://images.pexels.com/photos/25786565/pexels-photo-25786565.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const highlights = [
  { icon: Wifi, label: 'Free Wi-Fi' },
  { icon: Mountain, label: 'Lake and mountain views' },
  { icon: Car, label: 'Maxi cab taxi service' },
];

function HeroSection() {
  return (
    <section id="top" className="relative flex min-h-[92vh] items-end overflow-hidden bg-lake-900 text-white">
      <img
        src={HERO_IMAGE}
        alt="Dal Lake with snow-capped mountains and traditional boats"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-lake-900 via-lake-900/60 to-lake-900/20" />

      <div className="relative mx-auto w-full max-w-6xl px-6 pb-16 pt-40 md:pb-24">
        <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-saffron-300">
          Beside Dal Lake, Srinagar
        </p>
        <h1 className="max-w-3xl font-serif text-5xl leading-[1.1] md:text-7xl">
          Wake up to {homestay.name}, with the lake at your door.
        </h1>
        <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/90">
          Warm rooms with lake and mountain views, free Wi-Fi, home-cooked Kashmiri meals, and
          Maxi cab taxis to take you wherever you need to go.
        </p>

        <div className="mt-10 flex flex-col gap-4 sm:flex-row">
          <a
            href="#book"
            className="inline-flex items-center justify-center rounded-full bg-saffron-400 px-7 py-3.5 text-base font-semibold text-walnut-900 shadow-lg shadow-black/20 transition-all hover:-translate-y-0.5 hover:bg-saffron-300"
          >
            Check availability
          </a>
          <a
            href="#rooms"
            className="inline-flex items-center justify-center rounded-full border border-white/60 px-7 py-3.5 text-base font-semibold text-white transition-colors hover:bg-white/10"
          >
            Explore rooms
          </a>
        </div>

        <p className="mt-6 text-sm text-white/80">Rooms from ₹1,800 to ₹2,600 per night</p>

        <ul className="mt-12 grid gap-3 sm:grid-cols-3">
          {highlights.map(({ icon: Icon, label }) => (
            <li
              key={label}
              className="flex items-center gap-3 rounded-2xl border border-white/20 bg-white/10 px-4 py-3 text-sm font-medium backdrop-blur-md"
            >
              <Icon size={20} className="shrink-0 text-saffron-300" aria-hidden="true" />
              {label}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export default HeroSection;
