import { Check, Users } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';
import { rooms } from '@/data/homestay';
import { formatRupees } from '@/lib/format';

function RoomsSection() {
  return (
    <section id="rooms" className="scroll-mt-20 bg-cream py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Rooms"
          title="Three rooms, each with its own view"
          description="Every room includes free Wi-Fi. Pick the view and comfort that suits your stay."
        />

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {rooms.map((room) => (
            <article
              key={room.id}
              className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-walnut-100 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={room.image}
                  alt={`${room.name} with ${room.view.toLowerCase()}`}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>

              <div className="flex flex-1 flex-col p-7">
                <p className="text-sm font-semibold text-lake-600">{room.view}</p>
                <h3 className="mt-2 font-serif text-2xl text-walnut-900">{room.name}</h3>
                <p className="mt-3 leading-relaxed text-walnut-700">{room.description}</p>

                <ul className="mt-6 space-y-2.5">
                  {room.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm text-walnut-800">
                      <Check size={16} className="shrink-0 text-success-600" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto flex items-end justify-between gap-4 border-t border-walnut-100 pt-6">
                  <div>
                    <p className="font-serif text-3xl text-walnut-900">{formatRupees(room.pricePerNight)}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-sm text-walnut-700">
                      <Users size={14} aria-hidden="true" />
                      Up to {room.maxGuests} guests, per night
                    </p>
                  </div>
                  <a
                    href="#book"
                    className="shrink-0 rounded-full bg-lake-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-lake-700"
                  >
                    Book
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default RoomsSection;
