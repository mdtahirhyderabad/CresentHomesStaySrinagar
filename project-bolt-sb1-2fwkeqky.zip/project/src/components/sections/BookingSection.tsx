import { useState, type FormEvent, type ReactNode } from 'react';
import { CalendarDays, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';
import { mealPlans, rooms } from '@/data/homestay';
import { formatRupees } from '@/lib/format';
import {
  emptyBookingValues,
  submitBookingRequest,
  validateBooking,
  type BookingErrors,
  type BookingFormValues,
} from '@/lib/bookingRequest';

type SubmitStatus = 'idle' | 'submitting' | 'success' | 'error';

const inputClass =
  'w-full rounded-xl border bg-white px-4 py-3 text-walnut-900 placeholder:text-walnut-400 outline-none transition-colors focus:border-lake-500 focus:ring-4 focus:ring-lake-100';

function todayIso(): string {
  return new Date().toLocaleDateString('en-CA');
}

function nightsBetween(checkIn: string, checkOut: string): number {
  const ms = Date.parse(checkOut) - Date.parse(checkIn);
  return Number.isNaN(ms) || ms <= 0 ? 0 : Math.round(ms / 86_400_000);
}

type FieldProps = {
  label: string;
  error?: string;
  children: ReactNode;
  className?: string;
};

function Field({ label, error, children, className = '' }: FieldProps) {
  return (
    <label className={`flex flex-col gap-2 text-sm font-medium text-walnut-800 ${className}`}>
      {label}
      {children}
      {error && <span className="text-sm font-normal text-error-600">{error}</span>}
    </label>
  );
}

function BookingSection() {
  const [values, setValues] = useState<BookingFormValues>(emptyBookingValues);
  const [errors, setErrors] = useState<BookingErrors>({});
  const [status, setStatus] = useState<SubmitStatus>('idle');
  const [submitError, setSubmitError] = useState('');

  const selectedRoom = rooms.find((room) => room.id === values.roomId);
  const selectedPlan = mealPlans.find((plan) => plan.id === values.mealPlanId);
  const nights = nightsBetween(values.checkIn, values.checkOut);
  const guestCount = Number(values.guests) || 1;
  const roomTotal = selectedRoom ? selectedRoom.pricePerNight * nights : 0;
  const mealTotal = selectedPlan ? selectedPlan.pricePerPerson * guestCount * nights : 0;

  function updateField<K extends keyof BookingFormValues>(key: K, value: BookingFormValues[K]) {
    setValues((current) => {
      const next = { ...current, [key]: value };
      const room = rooms.find((item) => item.id === next.roomId);
      if (room && Number(next.guests) > room.maxGuests) {
        next.guests = String(room.maxGuests);
      }
      return next;
    });
    setErrors((current) => ({ ...current, [key]: undefined }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const validationErrors = validateBooking(values, todayIso());
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setStatus('submitting');
    setSubmitError('');
    try {
      await submitBookingRequest(values);
      setValues(emptyBookingValues);
      setStatus('success');
    } catch {
      setSubmitError('We could not send your request just now. Please try again, or call us directly.');
      setStatus('error');
    }
  }

  return (
    <section id="book" className="scroll-mt-20 bg-white py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Book your stay"
          title="Request your dates in a minute"
          description="Send your request and we will confirm your booking by email or phone."
        />

        <div className="mt-16 grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          <aside className="h-fit rounded-3xl bg-lake-900 p-8 text-white lg:sticky lg:top-28">
            <CalendarDays size={28} className="text-saffron-300" aria-hidden="true" />
            <h3 className="mt-5 font-serif text-2xl">Your estimate</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/85">
              Room rates are per night. Meals are charged separately and added to your bill.
            </p>

            <dl className="mt-8 space-y-4 text-sm">
              <div className="flex justify-between gap-4 border-b border-white/15 pb-4">
                <dt className="text-white/85">Room</dt>
                <dd className="text-right font-medium">{selectedRoom?.name ?? '-'}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b border-white/15 pb-4">
                <dt className="text-white/85">Nights</dt>
                <dd className="font-medium">{nights || '-'}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b border-white/15 pb-4">
                <dt className="text-white/85">Room total</dt>
                <dd className="font-medium">{nights ? formatRupees(roomTotal) : '-'}</dd>
              </div>
              <div className="flex justify-between gap-4 pb-1">
                <dt className="text-white/85">Meals (estimate)</dt>
                <dd className="font-medium">{nights && mealTotal > 0 ? formatRupees(mealTotal) : 'None'}</dd>
              </div>
            </dl>
          </aside>

          {status === 'success' ? (
            <div
              role="status"
              className="flex flex-col items-start justify-center rounded-3xl bg-success-50 p-10 ring-1 ring-success-100"
            >
              <CheckCircle2 size={48} className="text-success-600" aria-hidden="true" />
              <h3 className="mt-6 font-serif text-3xl text-walnut-900">Thank you, your request is in</h3>
              <p className="mt-4 text-lg leading-relaxed text-walnut-700">
                We have received your dates and will confirm your booking shortly by email or phone.
              </p>
              <button
                type="button"
                onClick={() => setStatus('idle')}
                className="mt-8 rounded-full bg-lake-600 px-6 py-3 font-semibold text-white transition-colors hover:bg-lake-700"
              >
                Send another request
              </button>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              noValidate
              className="grid gap-5 rounded-3xl bg-cream p-6 ring-1 ring-walnut-100 sm:grid-cols-2 md:p-10"
            >
              <Field label="Full name" error={errors.guestName} className="sm:col-span-2">
                <input
                  type="text"
                  autoComplete="name"
                  value={values.guestName}
                  onChange={(e) => updateField('guestName', e.target.value)}
                  placeholder="Your full name"
                  className={`${inputClass} ${errors.guestName ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              <Field label="Email" error={errors.guestEmail}>
                <input
                  type="email"
                  autoComplete="email"
                  value={values.guestEmail}
                  onChange={(e) => updateField('guestEmail', e.target.value)}
                  placeholder="you@example.com"
                  className={`${inputClass} ${errors.guestEmail ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              <Field label="Phone" error={errors.guestPhone}>
                <input
                  type="tel"
                  autoComplete="tel"
                  value={values.guestPhone}
                  onChange={(e) => updateField('guestPhone', e.target.value)}
                  placeholder="+91 98765 43210"
                  className={`${inputClass} ${errors.guestPhone ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              <Field label="Check-in" error={errors.checkIn}>
                <input
                  type="date"
                  min={todayIso()}
                  value={values.checkIn}
                  onChange={(e) => updateField('checkIn', e.target.value)}
                  className={`${inputClass} ${errors.checkIn ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              <Field label="Check-out" error={errors.checkOut}>
                <input
                  type="date"
                  min={values.checkIn || todayIso()}
                  value={values.checkOut}
                  onChange={(e) => updateField('checkOut', e.target.value)}
                  className={`${inputClass} ${errors.checkOut ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              <Field label="Room" error={errors.roomId}>
                <select
                  value={values.roomId}
                  onChange={(e) => updateField('roomId', e.target.value)}
                  className={`${inputClass} ${errors.roomId ? 'border-error-600' : 'border-walnut-200'}`}
                >
                  {rooms.map((room) => (
                    <option key={room.id} value={room.id}>
                      {room.name} ({formatRupees(room.pricePerNight)} per night)
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Guests" error={errors.guests}>
                <select
                  value={values.guests}
                  onChange={(e) => updateField('guests', e.target.value)}
                  className={`${inputClass} ${errors.guests ? 'border-error-600' : 'border-walnut-200'}`}
                >
                  {Array.from({ length: selectedRoom?.maxGuests ?? 4 }, (_, index) => index + 1).map((count) => (
                    <option key={count} value={count}>
                      {count} {count === 1 ? 'guest' : 'guests'}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Meals" error={errors.mealPlanId} className="sm:col-span-2">
                <select
                  value={values.mealPlanId}
                  onChange={(e) => updateField('mealPlanId', e.target.value)}
                  className={`${inputClass} ${errors.mealPlanId ? 'border-error-600' : 'border-walnut-200'}`}
                >
                  {mealPlans.map((plan) => (
                    <option key={plan.id} value={plan.id}>
                      {plan.label}
                      {plan.pricePerPerson > 0 ? ` (${formatRupees(plan.pricePerPerson)} per person per day)` : ''}
                    </option>
                  ))}
                </select>
              </Field>

              <Field label="Message (optional)" error={errors.message} className="sm:col-span-2">
                <textarea
                  rows={4}
                  value={values.message}
                  onChange={(e) => updateField('message', e.target.value)}
                  placeholder="Arrival time, airport pickup, or anything else we should know"
                  className={`${inputClass} resize-none ${errors.message ? 'border-error-600' : 'border-walnut-200'}`}
                />
              </Field>

              {status === 'error' && (
                <div
                  role="alert"
                  className="flex items-start gap-3 rounded-xl bg-error-50 p-4 text-sm text-error-700 sm:col-span-2"
                >
                  <AlertCircle size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
                  <p>{submitError}</p>
                </div>
              )}

              <div className="flex flex-col gap-3 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm text-walnut-700">We never charge you here. We confirm first.</p>
                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-saffron-400 px-8 py-3.5 font-semibold text-walnut-900 transition-all hover:-translate-y-0.5 hover:bg-saffron-300 disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {status === 'submitting' && <Loader2 size={18} className="animate-spin" aria-hidden="true" />}
                  {status === 'submitting' ? 'Sending request' : 'Send booking request'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

export default BookingSection;
