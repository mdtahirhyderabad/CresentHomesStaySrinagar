import { MapPin, Phone, MessageCircle, Navigation, Sunrise } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';
import { homestay } from '@/data/homestay';

const contactItems = [
  {
    icon: MapPin,
    label: 'Address',
    value: homestay.location,
    href: homestay.mapsUrl,
  },
  {
    icon: Phone,
    label: 'Call us',
    value: homestay.phoneDisplay,
    href: `tel:${homestay.phoneTel}`,
  },
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    value: 'Message us for quick replies',
    href: `https://wa.me/${homestay.whatsappNumber}`,
  },
];

function ContactSection() {
  return (
    <section id="contact" className="scroll-mt-20 bg-cream py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Contact"
          title="We are a message away"
          description="Ask about airport pickups, room availability, or the best time to see the lake."
        />

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {contactItems.map(({ icon: Icon, label, value, href }) => (
            <a
              key={label}
              href={href}
              target={href.startsWith('http') ? '_blank' : undefined}
              rel={href.startsWith('http') ? 'noreferrer' : undefined}
              className="group flex flex-col rounded-3xl bg-white p-8 ring-1 ring-walnut-100 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-lake-50 text-lake-700 transition-colors group-hover:bg-lake-600 group-hover:text-white">
                <Icon size={22} aria-hidden="true" />
              </div>
              <p className="mt-6 text-sm font-semibold uppercase tracking-wider text-walnut-600">{label}</p>
              <p className="mt-2 text-lg leading-snug text-walnut-900">{value}</p>
            </a>
          ))}
        </div>

        <div className="mt-6 flex flex-col items-start justify-between gap-6 rounded-3xl bg-lake-900 p-8 text-white md:flex-row md:items-center md:p-10">
          <div className="flex items-start gap-4">
            <Sunrise size={26} className="mt-1 shrink-0 text-saffron-300" aria-hidden="true" />
            <div>
              <h3 className="font-serif text-2xl">Ready to see the lake?</h3>
              <p className="mt-2 text-white/85">Find us on the map and plan your arrival from the city or airport.</p>
            </div>
          </div>
          <a
            href={homestay.mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex shrink-0 items-center gap-2 rounded-full bg-saffron-400 px-6 py-3 font-semibold text-walnut-900 transition-colors hover:bg-saffron-300"
          >
            <Navigation size={18} aria-hidden="true" />
            Get directions
          </a>
        </div>
      </div>
    </section>
  );
}

export default ContactSection;
