import { Car, Wifi, Utensils } from 'lucide-react';
import SectionHeading from '@/components/ui/SectionHeading';
import { foodMenu } from '@/data/homestay';
import { formatRupees } from '@/lib/format';

function StaySection() {
  return (
    <section id="stay" className="scroll-mt-20 bg-walnut-50 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="The stay"
          title="Everything you need, close to the water"
          description="Free Wi-Fi comes with every room. Meals and taxi rides are there when you want them."
        />

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          <article className="flex flex-col rounded-3xl bg-lake-700 p-8 text-white shadow-lg">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15">
              <Wifi size={26} aria-hidden="true" />
            </div>
            <h3 className="mt-6 font-serif text-2xl">Free Wi-Fi</h3>
            <p className="mt-3 leading-relaxed text-white/90">
              Stay connected throughout the property at no extra cost, from your room to the lakeside
              terrace. Ideal for travellers who work remotely or want to share their photos.
            </p>
            <span className="mt-8 inline-flex w-fit items-center rounded-full bg-saffron-400 px-4 py-1.5 text-sm font-semibold text-walnut-900">
              Included in every stay
            </span>
          </article>

          <article className="flex flex-col rounded-3xl bg-white p-8 shadow-sm ring-1 ring-walnut-100">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-saffron-300/40 text-walnut-900">
              <Utensils size={26} aria-hidden="true" />
            </div>
            <h3 className="mt-6 font-serif text-2xl text-walnut-900">Kashmiri food</h3>
            <p className="mt-3 leading-relaxed text-walnut-700">
              Home-cooked meals made with local recipes. Meals are paid separately, and you can add
              them to any room.
            </p>
            <ul className="mt-6 divide-y divide-walnut-100">
              {foodMenu.map((item) => (
                <li key={item.name} className="flex items-center justify-between gap-4 py-3 text-sm">
                  <span className="text-walnut-800">{item.name}</span>
                  <span className="shrink-0 font-semibold text-walnut-900">{formatRupees(item.price)}</span>
                </li>
              ))}
            </ul>
          </article>

          <article className="flex flex-col rounded-3xl bg-white p-8 shadow-sm ring-1 ring-walnut-100">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-lake-100 text-lake-700">
              <Car size={26} aria-hidden="true" />
            </div>
            <h3 className="mt-6 font-serif text-2xl text-walnut-900">Maxi cab taxis</h3>
            <p className="mt-3 leading-relaxed text-walnut-700">
              Shared Maxi cab taxis are available for trips across Srinagar. Ask us to arrange a pickup
              from the airport, the railway station, or the city.
            </p>
            <a
              href="#contact"
              className="mt-8 inline-flex w-fit items-center rounded-full border border-lake-600 px-5 py-2.5 text-sm font-semibold text-lake-700 transition-colors hover:bg-lake-600 hover:text-white"
            >
              Ask about a pickup
            </a>
          </article>
        </div>
      </div>
    </section>
  );
}

export default StaySection;
