type SectionHeadingProps = {
  eyebrow: string;
  title: string;
  description?: string;
};

function SectionHeading({ eyebrow, title, description }: SectionHeadingProps) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-lake-600">{eyebrow}</p>
      <h2 className="mt-3 font-serif text-4xl leading-[1.15] text-walnut-900 md:text-5xl">{title}</h2>
      {description && <p className="mt-4 text-lg leading-relaxed text-walnut-700">{description}</p>}
    </div>
  );
}

export default SectionHeading;
