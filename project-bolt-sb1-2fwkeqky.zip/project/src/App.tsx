import SiteHeader from '@/components/layout/SiteHeader';
import SiteFooter from '@/components/layout/SiteFooter';
import HeroSection from '@/components/sections/HeroSection';
import RoomsSection from '@/components/sections/RoomsSection';
import StaySection from '@/components/sections/StaySection';
import GallerySection from '@/components/sections/GallerySection';
import BookingSection from '@/components/sections/BookingSection';
import ContactSection from '@/components/sections/ContactSection';

function App() {
  return (
    <div className="min-h-screen bg-cream font-sans text-walnut-900 antialiased">
      <SiteHeader />
      <main>
        <HeroSection />
        <RoomsSection />
        <StaySection />
        <GallerySection />
        <BookingSection />
        <ContactSection />
      </main>
      <SiteFooter />
    </div>
  );
}

export default App;
