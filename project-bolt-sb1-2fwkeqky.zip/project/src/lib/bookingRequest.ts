import { mealPlans, rooms, type MealPlanId, type RoomId } from '@/data/homestay';
import { supabase } from '@/lib/supabase';

export type BookingFormValues = {
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  checkIn: string;
  checkOut: string;
  guests: string;
  roomId: string;
  mealPlanId: string;
  message: string;
};

export type BookingErrors = Partial<Record<keyof BookingFormValues, string>>;

export const emptyBookingValues: BookingFormValues = {
  guestName: '',
  guestEmail: '',
  guestPhone: '',
  checkIn: '',
  checkOut: '',
  guests: '2',
  roomId: 'lakeview-classic',
  mealPlanId: 'room-only',
  message: '',
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateBooking(values: BookingFormValues, today: string): BookingErrors {
  const errors: BookingErrors = {};
  const name = values.guestName.trim();
  const phone = values.guestPhone.trim();
  const email = values.guestEmail.trim();
  const guests = Number(values.guests);
  const room = rooms.find((item) => item.id === (values.roomId as RoomId));

  if (name.length < 2) errors.guestName = 'Please enter your full name.';
  if (!EMAIL_PATTERN.test(email)) errors.guestEmail = 'Please enter a valid email address.';
  if (phone.length < 7 || phone.length > 20) errors.guestPhone = 'Please enter a valid phone number.';

  if (!values.checkIn) {
    errors.checkIn = 'Choose a check-in date.';
  } else if (values.checkIn < today) {
    errors.checkIn = 'Check-in cannot be in the past.';
  }

  if (!values.checkOut) {
    errors.checkOut = 'Choose a check-out date.';
  } else if (values.checkIn && values.checkOut <= values.checkIn) {
    errors.checkOut = 'Check-out must be after check-in.';
  }

  if (!room) {
    errors.roomId = 'Choose a room.';
  } else if (!Number.isInteger(guests) || guests < 1 || guests > room.maxGuests) {
    errors.guests = `This room holds up to ${room.maxGuests} guests.`;
  }

  if (!mealPlans.some((plan) => plan.id === (values.mealPlanId as MealPlanId))) {
    errors.mealPlanId = 'Choose a meal plan.';
  }

  if (values.message.trim().length > 500) {
    errors.message = 'Please keep your message under 500 characters.';
  }

  return errors;
}

export async function submitBookingRequest(values: BookingFormValues): Promise<void> {
  const { error } = await supabase.from('booking_requests').insert({
    guest_name: values.guestName.trim(),
    guest_email: values.guestEmail.trim(),
    guest_phone: values.guestPhone.trim(),
    check_in: values.checkIn,
    check_out: values.checkOut,
    guests: Number(values.guests),
    room_type: values.roomId,
    meal_plan: values.mealPlanId,
    message: values.message.trim() || null,
  });

  if (error) {
    throw new Error(error.message);
  }
}
