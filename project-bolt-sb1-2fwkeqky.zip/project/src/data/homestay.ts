export const homestay = {
  name: 'Crescent Homestay',
  location: 'Dal Lake, Srinagar, Pedestrian Mall Road, near Hotel Heaven Canal',
  phoneDisplay: '+91 91038 04493',
  phoneTel: '+919103804493',
  whatsappNumber: '919103804493',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Pedestrian+Mall+Road+near+Hotel+Heaven+Canal+Dal+Lake+Srinagar',
} as const;

export type RoomId = 'lakeview-classic' | 'lake-deluxe' | 'mountain-suite';

export type Room = {
  id: RoomId;
  name: string;
  view: string;
  description: string;
  pricePerNight: number;
  maxGuests: number;
  image: string;
  features: string[];
};

export const rooms: Room[] = [
  {
    id: 'lakeview-classic',
    name: 'Lakeview Classic',
    view: 'Dal Lake view',
    description:
      'A warm wooden room with a big window that frames the water, ideal for couples and short stays.',
    pricePerNight: 1800,
    maxGuests: 2,
    image: 'https://images.pexels.com/photos/5439502/pexels-photo-5439502.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    features: ['Free Wi-Fi', 'Lake-facing window', 'Hot water', 'Breakfast available'],
  },
  {
    id: 'lake-deluxe',
    name: 'Lake Deluxe',
    view: 'Lake and mountain view',
    description:
      'A spacious room with twin beds, soft furnishings, and sunrise light over the lake and hills.',
    pricePerNight: 2200,
    maxGuests: 3,
    image: 'https://images.pexels.com/photos/9420758/pexels-photo-9420758.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    features: ['Free Wi-Fi', 'Twin beds option', 'Hot water', 'Meals available'],
  },
  {
    id: 'mountain-suite',
    name: 'Mountain Suite',
    view: 'Panoramic lake and mountain view',
    description:
      'Our top room with an attic-style loft, wooden paneling, and the widest view of the lake and hills.',
    pricePerNight: 2600,
    maxGuests: 4,
    image: 'https://images.pexels.com/photos/7746575/pexels-photo-7746575.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    features: ['Free Wi-Fi', 'Loft space', 'Hot water', 'Meals available'],
  },
];

export type MealPlanId = 'room-only' | 'breakfast' | 'breakfast-dinner';

export type MealPlan = {
  id: MealPlanId;
  label: string;
  description: string;
  pricePerPerson: number;
};

export const mealPlans: MealPlan[] = [
  {
    id: 'room-only',
    label: 'Room only',
    description: 'Just the room. Order meals from our kitchen whenever you like.',
    pricePerPerson: 0,
  },
  {
    id: 'breakfast',
    label: 'Breakfast',
    description: 'Freshly made breakfast served each morning.',
    pricePerPerson: 300,
  },
  {
    id: 'breakfast-dinner',
    label: 'Breakfast and dinner',
    description: 'Breakfast plus a home-cooked Kashmiri dinner.',
    pricePerPerson: 700,
  },
];

export const foodMenu = [
  { name: 'Kahwa (saffron green tea)', price: 60 },
  { name: 'Milk tea', price: 20 },
  { name: 'Noon chai (pink salt tea)', price: 60 },
  { name: 'Dum aloo Kashmiri', price: 600 },
  { name: 'Rogan josh', price: 400 },
  { name: 'Yakhni (yogurt lamb curry)', price: 400 },
  { name: 'Kashmiri thali', price: 999 },
];

export const galleryImages = [
  {
    src: 'https://images.pexels.com/photos/25786565/pexels-photo-25786565.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'Dal Lake with snow-capped Himalayan mountains and traditional boats',
    caption: 'Dal Lake at dawn',
  },
  {
    src: 'https://images.pexels.com/photos/40348598/pexels-photo-40348598.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'A shikara boat gliding across calm lake water',
    caption: 'Shikara on the water',
  },
  {
    src: 'https://images.pexels.com/photos/33466692/pexels-photo-33466692.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'Colorful shikaras resting on the lake with mountains behind',
    caption: 'Shikaras and mountains',
  },
  {
    src: 'https://images.pexels.com/photos/37106155/pexels-photo-37106155.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'Tranquil lake surrounded by towering mountains under a blue sky',
    caption: 'Mountains above the lake',
  },
  {
    src: 'https://images.pexels.com/photos/37420999/pexels-photo-37420999.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'A traditional Indian thali with flatbread, curry, and chutney',
    caption: 'Home-cooked meals',
  },
  {
    src: 'https://images.pexels.com/photos/11344437/pexels-photo-11344437.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    alt: 'Peaceful sunrise over a mountain lake with silhouetted trees',
    caption: 'Sunrise over the water',
  },
];
